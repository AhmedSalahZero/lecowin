<!doctype html>
<html>
<head></head>
<body>
<h4>You are receiving this email because we received a password reset request for your account.</h4>
<a  style="
color: #FFF;
    background-color: #32c5d2;
margin-top: 1px;
display: inline-block;
    margin-bottom: 0;
    font-weight: 400;
    text-align: center;
    vertical-align: middle;
    touch-action: manipulation;
    cursor: pointer;
    border: 1px solid transparent;
    white-space: nowrap;
    padding: 6px 12px;
    font-size: 14px;

" href="{{$link}}">
    Reset
</a>
<br>
<p>If you did not request a password reset, no further action is required.</p>
</body>
</html>
